class Colors:
    # Background
    dark_grey = (12, 12, 18)      

    # block
    green = (72, 201, 116)
    red = (255, 82, 82)
    orange = (255, 159, 67)
    yellow = (255, 214, 77)
    purple = (166, 102, 255)
    cyan = (64, 210, 255)
    blue = (76, 114, 255)

    # UI
    white = (245, 247, 250)
    dark_blue = (28, 35, 60)       
    light_blue = (100, 180, 255)
    easy = (100, 255, 150)
    medium = (255, 210, 80)
    hard = (255, 90, 80)
    level = (160, 200, 255)

    @classmethod
    def get_cell_colors(cls):
        return [
            cls.dark_grey,
            cls.green,
            cls.red,
            cls.orange,
            cls.yellow,
            cls.purple,
            cls.cyan,
            cls.blue
        ]