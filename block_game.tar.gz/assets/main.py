import pygame, sys, asyncio
from game import Game
from color import Colors

pygame.init()

title_font = pygame.font.Font(None, 40)
score_surface = title_font.render("Score", True, Colors.white)

next_surface = title_font.render("Next", True, Colors.white)
game_over_surface = title_font.render(" Game Over", True, Colors.white)

# levels
select_title   = title_font.render("SELECT LEVEL", True, Colors.white)
easy_level     = title_font.render("1  -  EASY", True, Colors.easy)
medium_level   = title_font.render("2  -  MEDIUM", True, Colors.medium)
hard_level     = title_font.render("3  -  HARD", True, Colors.hard)
instruction    = title_font.render("Press 1, 2 or 3", True, Colors.level)

score_rect = pygame.Rect(320, 55, 170, 70)
next_rect = pygame.Rect(320, 215, 170, 180)

# width , height
screen = pygame.display.set_mode((500, 620))
pygame.display.set_caption("Block Game")

clock = pygame.time.Clock()

game = Game()

SELECTING_LEVEL = 0
PLAYING = 1

state = SELECTING_LEVEL
level = None
fall_speed = 250

LEFT_REPEAT_DELAY = 150
RIGHT_REPEAT_DELAY = 150
DOWN_REPEAT_DELAY = 50

fall_timer = 0

left_held = False
right_held = False
down_held = False
left_timer = 0
right_timer = 0
down_timer = 0


async def main():

    global state, game, level, fall_speed, screen
    global fall_timer, left_held, right_held, down_held
    global left_timer, right_timer, down_timer

    while True:
        dt = clock.tick(60)
        if state == PLAYING and not game.game_over:
            # block fall speed
            fall_timer += dt
            if fall_timer >= fall_speed:
                fall_timer = 0
                game.move_down()

            # key repeat: left
            if left_held:
                left_timer += dt
                if left_timer >= LEFT_REPEAT_DELAY:
                    left_timer = 0
                    game.move_left()

            # key repeat: right
            if right_held:
                right_timer += dt
                if right_timer >= RIGHT_REPEAT_DELAY:
                    right_timer = 0
                    game.move_right()

            # key repeat: down
            if down_held:
                down_timer += dt
                if down_timer >= DOWN_REPEAT_DELAY:
                    down_timer = 0
                    game.move_down()
                    game.update_score(0, 5)

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

            # ========== LEVEL SELECTION ==========
            if state == SELECTING_LEVEL:
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_1:
                        level = "easy"
                        fall_speed = 450
                        state = PLAYING
                        fall_timer = 0
                        game = Game()          # restart game fresh

                    elif event.key == pygame.K_2:
                        level = "medium"
                        fall_speed = 250
                        state = PLAYING
                        fall_timer = 0
                        game = Game()

                    elif event.key == pygame.K_3:
                        level = "hard"
                        fall_speed = 150
                        state = PLAYING
                        fall_timer = 0
                        game = Game()

            # ========== PLAYING ==========
            elif state == PLAYING:
                if event.type == pygame.KEYDOWN:
                    if game.game_over:
                        # When game over, go back to level selection
                        state = SELECTING_LEVEL
                        game.game_over = False
                        left_held = right_held = down_held = False
                    else:
                        if event.key == pygame.K_LEFT and not left_held:
                            game.move_left()
                            left_held = True
                            left_timer = 0

                        if event.key == pygame.K_RIGHT and not right_held:
                            game.move_right()
                            right_held = True
                            right_timer = 0

                        if event.key == pygame.K_DOWN and not down_held:
                            game.move_down()
                            game.update_score(0, 5)
                            down_held = True
                            down_timer = 0

                        if event.key == pygame.K_UP:
                            game.rotate()

                if event.type == pygame.KEYUP:
                    if event.key == pygame.K_LEFT:
                        left_held = False
                    if event.key == pygame.K_RIGHT:
                        right_held = False
                    if event.key == pygame.K_DOWN:
                        down_held = False

        # ========== DRAWING ==========
        screen.fill(Colors.dark_blue)

        if state == SELECTING_LEVEL:
            # Nice centered selection screen
            screen.blit(select_title, select_title.get_rect(centerx=250, centery=120))
            screen.blit(easy_level, easy_level.get_rect(centerx=250, centery=240))
            screen.blit(medium_level, medium_level.get_rect(centerx=250, centery=310))
            screen.blit(hard_level, hard_level.get_rect(centerx=250, centery=380))
            screen.blit(instruction, instruction.get_rect(centerx=250, centery=480))

        else:
            # Normal game drawing
            score_value_surface = title_font.render(str(game.score), True, Colors.white)

            screen.blit(score_surface, (365, 20))
            screen.blit(next_surface, (375, 180))

            if game.game_over:
                screen.blit(game_over_surface, (320, 450))

            pygame.draw.rect(screen, Colors.light_blue, score_rect, 0, 10)
            screen.blit(score_value_surface, score_value_surface.get_rect(centerx=score_rect.centerx, centery=score_rect.centery))
            pygame.draw.rect(screen, Colors.light_blue, next_rect, 0, 10)

            game.draw(screen)

        pygame.display.update()
        await asyncio.sleep(0)

asyncio.run(main())